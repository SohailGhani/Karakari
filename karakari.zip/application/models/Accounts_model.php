<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts_model extends CI_Model {

        public function get_accounts(){
            $this->db->select('*');
            $query=$this->db->get('accounts');
            return $query->result();
        }
        public function get_account($id){
            $this->db->select('*');
            $this->db->where('acId',$id);
            $query=$this->db->get('accounts');
            return $query->row_array();
        }
        function account_insert($data){
            
            $this->db->insert('accounts',$data);
            return $this->db->insert_id();
        }
        function account_update($data,$id){
            $this->db->where('acId',$id);
            $this->db->update('accounts', $data);
        }
        function account_delete($id){
            $this->db->where('acId',$id);
            $this->db->delete('accounts');
        }
        function update_stock($id,$quantity){
            $this->db->query("UPDATE items SET itemQuantity=(itemQuantity-$quantity) where itemId = $id");
        }
        public function get_transactions($id){
            $this->db->select('*');
            $this->db->where('acId',$id);
            $this->db->join('sales_metas','sales_metas.saleId=sales.saleId');
//            $this->db->join('items','sales_metas.items=items.itemName');
            $this->db->order_by('saleDate','DESC');
            $query=$this->db->get('sales');
            
            $result=$query->result();
//            print_r($result);exit;
            foreach($result as $recordy):
                $recordy->itemNames='';
                $this->db->select('*');
                $this->db->where('saleId',$recordy->saleId);
                $this->db->join('items','sales_metas.items=items.itemId');
                $meta_query=$this->db->get('sales_metas');
                $meta_result=$meta_query->result();
                foreach ($meta_result as $items):
                    $recordy->itemNames.=$items->itemName."($items->quantity), ";
//                    $this->update_stock($items->itemId, $items->quantity);
                endforeach;
            endforeach;
            return $result;
        }
        public function get_sale($id){
            $this->db->select('*');
            $this->db->where('sales.saleId',$id);
            $this->db->join('sales_metas','sales_metas.saleId=sales.saleId');
            $this->db->join('accounts','accounts.acId=sales.acId');
//            $this->db->join('items','sales_metas.items=items.itemName');
            $this->db->order_by('saleDate','DESC');
            $query=$this->db->get('sales');
            
            $result=$query->row_array();
//            print_r($result);exit;
                $result['itemNames']='';
                $this->db->select('*');
                $this->db->where('saleId',$result['saleId']);
                $this->db->join('items','sales_metas.items=items.itemId');
                $meta_query=$this->db->get('sales_metas');
                $result['itemNames']=$meta_query->result();
//                foreach ($meta_result as $items):
//                    $result['itemNames'].=$items->itemName."($items->quantity), ";
////                    $this->update_stock($items->itemId, $items->quantity);
//                endforeach;
            return $result;
        }
        function get_item_name($id){
            $this->db->select('itemName');
            $this->db->where('itemId',$id);
            $query=$this->db->get('items');
            $res=$query->row_array();
            return $res['itemName'];
        }
        public function get_transaction($id){
            $this->db->select('*');
            $this->db->where('saleId',$id);
            $query=$this->db->get('sales');
            return $query->row_array();
        }
        function transaction_insert($data){
            
            $this->db->insert('sales',$data);
            return $this->db->insert_id();
        }
        function meta_insert($data){
            
            $this->db->insert('sales_metas',$data);
            $this->update_stock($data['items'], $data['quantity']);
        }
//        function transaction_update($data,$id){
//            $this->db->where('transId',$id);
//            $this->db->update('transactions', $data);
//            $pw=$this->input->post('withdraw')-$this->input->post('prevwithdraw');
//            $pd=$this->input->post('deposit')-$this->input->post('prevdeposit');
//            $this->db->query("UPDATE accounts SET balance+= (".$pd."), balance(".$pw.") WHERE acId=".$data['acId']);
//        }
        function update_account_blance($id,$balance){
            $this->db->query("UPDATE accounts SET balance=balance+(".$balance.") WHERE acId=".$id);

        }
        function transaction_delete($id,$ac){
            
            $this->db->select('deposit,withdraw');
            $this->db->where('acId',$ac);
            $query=$this->db->get('transactions');
            $res=$query->row_array();
            $this->db->query("UPDATE accounts SET balance=balance-".$res['deposit'].", balance=balance+".$res['withdraw']." WHERE acId=".$ac);

            $this->db->where('transId',$id);
            $this->db->delete('transactions');
            
        }
        function deposite($id,$amount){
            $this->db->query("UPDATE accounts SET balance=balance-(".$amount.") WHERE acId=".$id);
        }
    function account_latest_date(){
            $this->db->select('accounts_meta.entryDate');
            $this->db->order_by('accounts_meta.entryDate','desc');
            $query = $this->db->get('accounts_meta',1);
            $res=$query->row_array();
            if($this->db->affected_rows()>0)
                return $res['entryDate'];
            else return false;
    }
    function next_day($data){
//        print_r($data);exit;
        $this->db->insert('accounts_meta',$data);
    }
    function get_closing($acId,$date){
        $this->db->select('closing');
        $this->db->where('acId',$acId);
        $this->db->where('entryDate',$date);
        $query = $this->db->get('accounts_meta',1);
        $res=$query->row_array();
        return $res['closing'];
    }    
        function get_qp(){
                $this->db->select('sales.amount_paid,sales.quantity');
                $query = $this->db->get('sales')->result();
                $result['quantity']=0;
                $result['amount_paid']=0;
                foreach($query as $temp):
                    $result['quantity']+=$temp->quantity; 
                    $result['amount_paid']+=($temp->amount_paid*$temp->quantity);
                endforeach;
                return $result;
    }
}