<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings_model extends CI_Model {

    public function get_items(){
            $this->db->select('*');
            $query=$this->db->get('items');
            return $query->result();
        }
    public function get_item($id){
            $this->db->select('*');
            $this->db->where('itemId',$id);
            $query=$this->db->get('items');
            return $query->row_array();
        }
        function currency_insert($data){
            $this->db->insert('items', $data);
            }
        function item_update($data,$id){
            $this->db->where('itemId',$id);
            $this->db->update('items', $data);
        }
        function item_delete($id){
            $this->db->where('itemId',$id);
            $this->db->delete('items');
        }
        
          
   
}
