 <footer class=content-footer> 
            <nav class=footer-left> 
                <ul class=nav> 
                    <li> 
                        <a href=javascript:;>Copyright 
                            <i class="fa fa-copyright"></i> 
                            <span>Innovision Tecnology</span> 2015. All rights reserved
                        </a> 
                    </li> 
                    <!--<li class="pull-right"><b>Cash: <?=$this->base_model->get_cash()?></b> PKR</li>-->
                </ul> 
            </nav> 
        </footer>     
         
    </div> 
    <?php if(!isset($hide_script)){ ?>
    <script src="<?=site_url('assets/scripts/app.min.4fc8dd6e.js')?>"></script> 
    <?php } ?>
    