
            <div class="main-content">
                <div class="row">
                    <div class="col-md-4"> 
                        <div class="widget bg-white no-padding"> 
                            <a href="<?=site_url('accounts/accounts_info')?>" class="block text-center relative p15"> 
                                <span class="fa fa-users"style="font-size: 100px"></span>
                                <div class="h5 mb0"><strong>Accounts</strong> 
                                </div> 
                            </a> 
<!--                            <div class="widget bg-blue mb0 text-center no-radius"> 
                                <div class="widget-details"> 
                                    <div class="h5 no-margin">782</div> 
                                    <div class="small bold text-uppercase">Followers</div> 
                                </div> <div class="widget-details"> 
                                    <div class="h5 no-margin">8,234</div> 
                                    <div class="small bold text-uppercase">Following</div> 
                                </div> <div class="widget-details"> 
                                    <div class="h5 no-margin">290,847</div> 
                                    <div class="small bold text-uppercase">Likes</div> 
                                </div> 
                            </div> -->
                        </div> 
                    </div>
                    
                    <div class="col-md-4"> 
                        <div class="widget bg-white no-padding"> 
                            <a href="<?=site_url('Users/user_info')?>" class="block text-center relative p15"> 
                                <span class="fa fa-clipboard"style="font-size: 100px"></span>
                                <div class="h5 mb0"><strong>Reports</strong> 
                                </div> 
                            </a> 
                            
                        </div> 
                    </div>
                    
        </div><!--Main content-->
  </div><!--Main Panel-->
 </div>