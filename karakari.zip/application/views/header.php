<!DOCTYPE html> <html class=no-js> 
<!-- Mirrored from urban.nyasha.me/html/extras-blank.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 17 Feb 2016 05:11:52 GMT -->
<head> <meta charset=utf-8> 
  <title>Karakari</title> 
  <meta name=description content=""> 
  <meta name=viewport content="width=device-width"> 
  <script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:0,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dok3v=1613a3a185/"},atok:"a130311581747a98ba6ff289bb1e5d73",petok:"b0eed27d37e632294d4321d489a4a61fb7470e86-1455685785-1800",zone:"nyasha.me",rocket:"0",apps:{"ga_key":{"ua":"UA-50530436-1","ga_bs":"2"}},sha2test:0}];!function(a,b){a=document.createElement("script"),b=document.getElementsByTagName("script")[0],a.async=!0,a.src="../../ajax.cloudflare.com/cdn-cgi/nexp/dok3v%3db3137422b2/cloudflare.min.js",b.parentNode.insertBefore(a,b)}()}}catch(e){};
//]]>
</script>
<link rel="shortcut icon" href="<?=site_url('http://urban.nyasha.me/favicon.ec0f3a1b.ico')?>">
<link rel=stylesheet href="<?=site_url('assets/styles/app.min.df5e9cc9.css')?>">
<link rel=stylesheet href="<?=site_url('assets/styles/fontawesome.min.css')?>">
<body>
    <div class=quick-launch-panel> 
        <div class=container> 
            <div class=quick-launcher-inner> 
                <a href=javascript:; class=close data-toggle=quick-launch-panel>�</a> 
                    <div class=css-table-xs> <div class=col> 
                        <a href=app-calendar.html> 
                            <i class=icon-marquee></i> 
                            <span>Calendar</span> 
                        </a> 
                    </div> 
                    <div class=col> 
                        <a href=app-gallery.html> 
                            <i class=icon-drop></i> 
                            <span>Gallery</span> 
                        </a> 
                    </div> 
                    <div class=col> 
                        <a href=app-messages.html> 
                            <i class=icon-mail></i> 
                            <span>Messages</span> 
                        </a> 
                    </div> 
                    <div class=col> 
                        <a href=app-social.html> 
                            <i class=icon-speech-bubble></i> 
                            <span>Social</span> 
                        </a> 
                    </div> 
                    <div class=col> 
                        <a href=charts-flot.html> 
                            <i class=icon-pie-graph></i> 
                            <span>Analytics</span> 
                        </a> 
                    </div>
                    <div class=col> 
                        <a href=javascript:;> 
                            <i class=icon-esc></i>
                            <span>Documentation</span> 
                        </a> 
                    </div> 
                </div> 
            </div> 
        </div> 
    </div>   
    <div class="app layout-fixed-header">   
        <div class="sidebar-panel offscreen-left"> 
            <div class="brand">   
                <div class="brand-logo"> 
                    <span class="fa fa-exchange"style="font-size: 30px"></span>
                </div>     
                
            </div>   
            <nav role=navigation> 
                <ul class=nav>   
                    <li> 
                        <a class="removehover" href="<?=site_url('Home')?>">
                            <span><h2>Dashboard</h2></span> 
                        </a> 
                    </li>     
                    <li> 
                        <a href="<?=site_url('accounts/accounts_info')?>"> 
                            <h4><i class="fa fa-ship"></i><span style="font-family: cursive">Accounts</span></h4> 
                        </a> 
                    </li>     
                    <li> 
                        <a href="<?=site_url('settings/item_view')?>"> 
                            <h4>
                            <i class="fa fa-tint"></i> 
                            <span style="font-family: cursive">Stock</span> 
                            </h4>
                        </a> 
                         
                    </li>     
                    
                    
                    
                    
                    
                   
                </ul> 
            </nav>   
        </div>     
        <div class=main-panel>   
            <header class="header navbar">
                <div class="brand visible-xs">   
                    
                    <div class=brand-logo> 
                        <img src=<?=site_url('assets/images/logo-dark.5ba260bb.png height=15 alt=""')?>> 
                    </div>     
                      
                </div> 
                <ul class="nav navbar-nav hidden-xs breadcrumb"> 
                   <li><a href="<?=site_url('Home')?>">Home</a></li>
                   <li class="active" style="margin-top: 17px"><?=$breadcrumb?></li>
                </ul> 
                <ul class="nav navbar-nav navbar-right hidden-xs"> 
                 
                    <li> 
                        <a href="<?=site_url('Users/logout')?>"> 
                            <img src="<?=site_url('assets/images/avatar.21d1cc35.jpg')?>" class="header-avatar img-circle ml10" alt="user" title="user"> 
                            <span class=pull-left>Log Out</span> 
                        </a> 
                        
                    </li> 
                    
                </ul> 
            </header>