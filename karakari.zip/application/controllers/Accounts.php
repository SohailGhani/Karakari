<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class accounts extends My_Controller {
        function __construct() {
       parent::__construct();
         $this->load->model('accounts_model');
   }
    
        function index(){
            $this->account_view();
        }
        public function account_view(){
            $data['breadcrumb']='Accounts';
            $data['page']='accounts/account_view';
            $this->load->view('template',$data);
        }
        public function accounts_info(){
            $data['breadcrumb']='Accounts';
            $data['accounts']=$this->accounts_model->get_accounts();
            $data['title']="Accounts Information";
            $data['page']='accounts/accounts';
            $this->load->view('template',$data);
        }
        public function accounts_json()
	{
            $data=  $this->accounts_model->get_accounts();
            
            echo '{ "accounts": '.json_encode($data).'}';
	}
        
        public function account_add(){
             $data['breadcrumb']='Accounts / Add Account';
            $this->load->library('form_validation');
            $data['page']='accounts/account_add';
            $data['action']=site_url("accounts/account_insert");
            $this->load->view('template',$data);
            
        }
        public function account_insert(){
            
            $data['name']=  $this->input->post('name');
            $data['address']=  $this->input->post('address');
            $data['nic']=  $this->input->post('nic');
            $data['entryDate']=  $this->input->post('entrydate');
            $data['phone']=  $this->input->post('phone');
            $data['email']=  $this->input->post('email');
            $data['fax']=  $this->input->post('fax');
            $data['balance']=  $this->input->post('balance');
            $this->accounts_model->account_insert($data);
            $this->session->set_userdata('msg','New Account has been successfully added');
            $this->session->set_userdata('msg_class','success');
            
            
            redirect("accounts/accounts_info/");
            
	}
        public function invoice($id,$acid){
            
            $data['breadcrumb']='Sales/ Sale_Edit';
            $data['sale']=$this->accounts_model->get_sale($id);
            $data['page']='accounts/invoice';
            $data['id']=$acid;
            $data['action']=site_url("accounts/account_update/$id");
            $this->load->view($data['page'],$data);
            
	}
        public function account_edit($id)
	{
            $data['breadcrumb']='Sales/ Sale_Edit';
            $data['account']=$this->accounts_model->get_account($id);
            $data['page']='accounts/account_edit';
            $data['action']=site_url("accounts/account_update/$id");
            $this->load->view('template',$data);
	}
        public function account_update($id){
            
            $data['name']=  $this->input->post('name');
            $data['address']=  $this->input->post('address');
            $data['nic']=  $this->input->post('nic');
            $data['entryDate']=  $this->input->post('entrydate');
            $data['phone']=  $this->input->post('phone');
            $data['email']=  $this->input->post('email');
            $data['fax']=  $this->input->post('fax');
            $data['balance']=  $this->input->post('balance');
           
            $this->accounts_model->account_update($data,$id);
            $this->session->set_userdata('msg','Account has been successfully Updated');
            $this->session->set_userdata('msg_class','success');
            redirect('accounts/accounts_info');
	}
        public function account_delete($id){
            $this->accounts_model->account_delete($id);
            $this->session->set_userdata('msg','Account has been successfully Deleted');
            $this->session->set_userdata('msg_class','danger');
            redirect('accounts/accounts_info');
        }
        
        public function transactions_info($id){
            $data['breadcrumb']='Accounts';
            $data['account']=$this->accounts_model->get_account($id);
            $data['hide_script']=1;
            $data['id']=$id;
            $data['title']="Accounts Information";
            $data['page']='accounts/transactions';
            $this->load->view('template',$data);
        }
        public function transactions_json($id)
	{
            $data=  $this->accounts_model->get_transactions($id);
            
            echo '{ "transactions": '.json_encode($data).'}';
	}
        
        public function transaction_add($id){
            $data['breadcrumb']='Accounts / Add Transaction';
            $data['id']=$id;
            $data['items']=$this->base_model->get_items();
            $data['accounts']=$this->accounts_model->get_accounts();
            $data['page']='accounts/transaction_add';
            $data['action']=site_url("accounts/transaction_insert");
            $this->load->view('template',$data);
            
        }
        public function deposite($id){
            $data['breadcrumb']='Accounts / Balance Desposite';
            $data['items']=$this->base_model->get_items();
            $data['accounts']=$this->accounts_model->get_accounts();
            $data['page']='accounts/balance_deposite';
            $data['action']=site_url("accounts/deposite_insert/$id");
            $this->load->view('template',$data);
            
        }
        public function deposite_insert($id){
            $data['breadcrumb']='Accounts / Balance Desposite';
            $deposit=$this->input->post('deposite');
            $this->accounts_model->deposite($id,$deposit);
             redirect("accounts/transactions_info/$id");
        }
        public function transaction_insert(){
            
            $id=$data['acId']=  $this->input->post('acid');
            $data['paid']=  $this->input->post('paid');
            $data['paidBy']=  $this->input->post('paidby');
            $data['total']=  $this->input->post('total');
            $data['saleDate']=  $this->input->post('date');
            $data['balance']=  $this->input->post('balance');
            $data['invoice']=  $this->input->post('invoice');
           $saleid= $this->accounts_model->transaction_insert($data);
           $this->accounts_model->update_account_blance($id,$data['balance']);
           $meta['items']=0;
           $meta['quantity']=0;
            for($i=0;$i<count($this->input->post('items'));$i++):
                $meta['items']=$this->input->post('items')[$i];
                $meta['quantity']=$this->input->post('quantity')[$i];
                $meta['price']=$this->input->post('price')[$i];
                $meta['saleId']=$saleid;
                $this->accounts_model->meta_insert($meta);
            endfor;
            $this->session->set_userdata('msg','New Transaction has been successfully added');
            $this->session->set_userdata('msg_class','success');
            
            redirect("accounts/invoice/$saleid/$id");
            
	}
//        public function transaction_edit($id)
//	{
//            $data['breadcrumb']='Sales/ Sale_Edit';
//            $data['transaction']=$this->accounts_model->get_transaction($id);
//            $data['page']='accounts/transaction_edit';
//            $data['id']=$id;
//            $data['action']=site_url("accounts/transaction_update/$id");
//            $this->load->view('template',$data);
//	}
//        public function transaction_update($id){
//            
//            $data['deposit']=  $this->input->post('deposit');
//            $data['withdraw']=  $this->input->post('withdraw');
//            $data['date']=  $this->input->post('date');
//            $data['acId']=  $this->input->post('acid');;
//            $this->accounts_model->transaction_update($data,$id);
//            $this->session->set_userdata('msg','Transaction has been successfully Updated');
//            $this->session->set_userdata('msg_class','success');
//            $id=$data['acId'];
//            redirect("accounts/transactions_info/$id");
//	}
            public function transaction_delete($id,$ac){
            $this->accounts_model->transaction_delete($id,$ac);
            $this->session->set_userdata('msg','Transaction has been successfully Deleted');
            $this->session->set_userdata('msg_class','danger');
            redirect("accounts/transactions_info/$ac");
        }
}


