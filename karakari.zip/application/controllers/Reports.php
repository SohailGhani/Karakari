<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends My_Controller {
        function __construct() {
       parent::__construct();
         $this->load->model('accounts_model');
         $this->load->model('settings_model');
         $this->load->model('report_model');
         
   }

        public function customer_summary()
	{
            if(!empty($this->input->post('date')))
                $data['date']=$this->input->post('date');
            else
                $data['date']=  date("Y-m-d");
            
            $data['hide_script']=1;
            $data['breadcrumb']='Reports / Customer Summary';
            $data['page']='reports/customer_summary';
            $data['accounts']=$this->accounts_model->get_accounts();
            $data['title']='Customers Summary';
            $data['action']=site_url("Reports/customer_summary/");
            $this->load->view('template',$data);
	}
        public function cash_summary()
	{
            if(!empty($this->input->post('date')))
                $data['date']=$this->input->post('date');
            else
                $data['date']=  date("Y-m-d");
            
            $data['hide_script']=1;
            $data['breadcrumb']='Reports / Cash Exchange Summary';
            $data['page']='reports/cash_exchange_summary';
            $data['currencies']=$this->settings_model->get_currencies();
            $data['title']='Cash Exchange Summary';
            $data['action']=site_url("Reports/cash_summary/");
            $this->load->view('template',$data);
	}
        function customer_search(){
            $data['page']='reports/search';
            $data['acc']=1; // for activating accounts loop
            $data['data']=$this->accounts_model->get_accounts();
            $data['title']='3d Party Report';
            $data['breadcrumb']='Reports / 3d Party Report';
            $data['action']=site_url('reports/customer_report');
            $this->load->view('template',$data);
        }
        function search(){
            $data['page']='reports/search';
            $data['title']='Sales Report';
            $data['breadcrumb']='Reports / Sales Search';
            $data['action']=  site_url('reports/sales_report');
            $this->load->view('template',$data);
        }
    public function sales_report()
	{
            $data['breadcrumb']='Cash Exchange Report';
            $data['results']=$this->report_model->sales_report($this->input->post('from'),$this->input->post('to'));
            $data['hide_script']=1;
            $data['title']='Sales Report ';
            $data['page']='Reports/report';
            $data['from']=  $this->input->post('from');
            $data['to']  =  $this->input->post('to');
            $data['action']=site_url('Reports/sales_report');
            $this->load->view('template',$data);
	} 
        public function customer_report()
	{
            $data['breadcrumb']='Customer Report';
            $data['results']=$this->report_model->customer_report($this->input->post('from'),$this->input->post('to'),$this->input->post('selection'));
            $data['hide_script']=1;
            $data['data']=$this->accounts_model->get_accounts();
            $data['title']='3rd Party Report ';
            $data['page']='Reports/customer_report';
            $data['from']=  $this->input->post('from');
            $data['to']  =  $this->input->post('to');
            $data['action']=site_url('Reports/customer_report');
            $this->load->view('template',$data);
	} 
        
}
